const http = require('http');
const api= require('./api');
const files= require('./files');



http.createServer(function(request, response) {
    let a=request.url.split('/');
    console.log(request.url);
    if (request.url.includes('..')){
        console.log("to filter");
    }
    
    
    if(a[1]=="api"){ return api.manage(request, response);}
    return files.manage(request, response);

}).listen(8000,"0.0.0.0",function(){ console.log("it works");});
